package com.online.course.model

interface ItemPicker {
    fun itemTitle(): String
}