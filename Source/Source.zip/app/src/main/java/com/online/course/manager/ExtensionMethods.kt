package com.online.course.manager

object ExtensionMethods {

}