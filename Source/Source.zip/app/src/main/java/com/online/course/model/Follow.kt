package com.online.course.model

import com.google.gson.annotations.SerializedName

class Follow {
    @SerializedName("status")
    var status = 0
}