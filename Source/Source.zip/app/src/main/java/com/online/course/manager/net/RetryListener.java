package com.online.course.manager.net;

@FunctionalInterface
public interface RetryListener {
    void onRetry();
}
